
//list of packets we need to encode on the way out:
E(OP_SendAATable)

//list of packets we need to decode on the way in:
D(OP_SetServerFilter)


#undef E
#undef D
