#ifndef TEMPLATE_STRUCTS_H_
#define TEMPLATE_STRUCTS_H_

namespace TEMPLATE {
	namespace structs {


//paste contents of eq_packet_structs.h here...



	};	//end namespace structs
};	//end namespace TEMPLATE




#endif /*TEMPLATE_STRUCTS_H_*/










