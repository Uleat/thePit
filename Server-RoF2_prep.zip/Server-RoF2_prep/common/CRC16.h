#ifndef _CRC16_H
#define _CRC16_H
#include "types.h"

uint16 CRC16(const unsigned char *buf, int size, int key);

#endif
