#ifndef __EQEMU_CRASH_H
#define __EQEMU_CRASH_H

void set_exception_handler();

#endif
