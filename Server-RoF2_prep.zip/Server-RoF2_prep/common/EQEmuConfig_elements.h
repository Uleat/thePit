ELEMENT(world)
ELEMENT(chatserver)
ELEMENT(mailserver)
ELEMENT(zones)
ELEMENT(database)
ELEMENT(qsdatabase)
ELEMENT(files)
ELEMENT(directories)
ELEMENT(launcher)

#undef ELEMENT
