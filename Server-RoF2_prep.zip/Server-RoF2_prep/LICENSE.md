The server code and utilities are released under GPLv3.

We also include some small libraries for convienence that may be under different licensing:

SocketLib - GPL
LibXML - ZLib License
StackWalker - New BSD License
ZLib - ZLib License
MySQL - GPL
Perl - GPL / ActiveState (under the assumption that this is a free project).
CPPUnit - GLP
StringUtilities - Apache