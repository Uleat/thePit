EQEmu - Custom Game Implementation for EverQuest

Dependencies can be obtained at http://eqemu.github.com/

More Information: https://github.com/EQEmu/Server/wiki
